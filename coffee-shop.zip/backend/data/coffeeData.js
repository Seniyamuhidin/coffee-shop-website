module.exports = [
  { id: 1, name: "Espresso", price: "$3" },
  { id: 2, name: "Cappuccino", price: "$4" },
  { id: 3, name: "Latte", price: "$4.5" },
];