import React from 'react';

function CoffeeList({ coffees }) {
  return (
    <div>
      <h3>Our Menu</h3>
      <ul>
        {coffees.map(coffee => (
          <li key={coffee.id}>
            {coffee.name} - {coffee.price}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default CoffeeList;