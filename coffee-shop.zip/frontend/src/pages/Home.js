import React, { useEffect, useState } from 'react';
import CoffeeList from '../components/CoffeeList';

function Home() {
  const [coffees, setCoffees] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/api/coffees")
      .then(res => res.json())
      .then(data => setCoffees(data));
  }, []);

  return (
    <div style={{ padding: '20px' }}>
      <h1>Welcome to Our Coffee Shop</h1>
      <CoffeeList coffees={coffees} />
    </div>
  );
}

export default Home;