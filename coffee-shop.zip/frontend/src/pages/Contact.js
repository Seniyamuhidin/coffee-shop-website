import React from 'react';

function Contact() {
  return (
    <div style={{ padding: '20px' }}>
      <h2>Contact Us</h2>
      <form>
        <input type="text" placeholder="Your Name" required /><br /><br />
        <input type="email" placeholder="Your Email" required /><br /><br />
        <textarea placeholder="Your Message" required></textarea><br /><br />
        <button type="submit">Send</button>
      </form>
    </div>
  );
}

export default Contact;